document.getElementById("btn").addEventListener("click", function() {
	alert("Hey, this works, too!");
});