var firstName = "John",
	lastName = "Smith",
	age;
	
age = 39;

console.log(firstName, lastName, age);