document.getElementById("btn").addEventListener("click", function() {
	console.log("Hey, this works, too!");
});