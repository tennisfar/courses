var cost = 10,
	quantity = 2;


if(quantity) {
	var total = cost * quantity;
	console.log("total: " + total);
}
else {
	console.log("quantity is not defined.");
}