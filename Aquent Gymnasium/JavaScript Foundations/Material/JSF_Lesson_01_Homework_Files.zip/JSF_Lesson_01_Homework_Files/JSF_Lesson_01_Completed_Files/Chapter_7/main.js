var term1 = "rat",
	term2 = "earth";
	
if(term2.indexOf(term1) != -1) {
	console.log(term2 + " contains " + term1);
}
else {
	console.log("There is no " + term1 + " in " + term2;
}