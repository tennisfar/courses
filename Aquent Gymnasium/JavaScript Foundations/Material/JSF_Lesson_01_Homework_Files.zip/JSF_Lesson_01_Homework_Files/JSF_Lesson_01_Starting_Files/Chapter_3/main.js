document.getElementById("btn").addEventListener("click", function(event) {
	alert("Hey, this works, too!");
});