var items = ["hammer",
			 "screwdriver",
			 "saw",
			 "chisel",
			 "vise",
			 "wrench",
			 "pliers",
			 "knife"];


items.push("paintbrush");

items.push("awl", "scraper", "dropcloth");

items.sort();

function listItems() {
	for(var i = 0; i < items.length; i++) {
		console.log(items[i]);
	}
}

listItems();