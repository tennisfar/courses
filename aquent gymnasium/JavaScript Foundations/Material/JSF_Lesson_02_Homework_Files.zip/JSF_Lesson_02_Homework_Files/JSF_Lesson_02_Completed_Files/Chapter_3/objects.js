var items = ["hammer",
			 "screwdriver",
			 "saw",
			 "chisel",
			 "vise",
			 "wrench",
			 "pliers",
			 "knife"];

var costs = [9.99,
			 3.99,
			 12.99,
			 7.99,
			 22.00,
			 6.99,
			 4.99,
			 5.99];

items.push("paintbrush");
costs.push(2.99);

items.push("awl", "scraper", "dropcloth");
costs.push(8.99, 1.99, 3.99);

items.sort();

function listItems() {
	for(var i = 0; i < items.length; i++) {
		console.log(items[i] + " is $" + costs[i]);
	}
}

listItems();