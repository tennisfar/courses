function sayHello(name, useAlert) {

	if(useAlert) {
		alert("Hello, " + name);
	}
	else {
		console.log("Hello, " + name);
	}
}

function randomInt(max) {
	var rand = Math.random() * max;
	rand = Math.round(rand);
	return rand;
}

// log a random whole number from 0 to 100
console.log(randomInt(100));

console.log(rand);

// sayHello("Tracey", true);