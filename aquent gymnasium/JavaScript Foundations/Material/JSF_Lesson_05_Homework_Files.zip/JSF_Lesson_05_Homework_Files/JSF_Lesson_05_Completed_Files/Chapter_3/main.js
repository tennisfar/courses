$.get("http://omdbapi.com/?s=star wars&r=XML", null, null, "text")
	.done(function(data){
		console.log(data);
})
.fail(function(){
	alert("request failed. Try again");
});
