$.get("http://api.openweathermap.org/data/2.5/weather?q=Boston,ma&units=imperial")
	.done(function(data){
		console.log(data);
})
.fail(function(){
	alert("request failed. Try again");
});
