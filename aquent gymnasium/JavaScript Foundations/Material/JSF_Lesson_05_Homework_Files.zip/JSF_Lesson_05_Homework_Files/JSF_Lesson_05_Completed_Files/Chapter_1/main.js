$.get("http://api.openweathermap.org/data/2.5/weather?q=Boston,ma&units=imperial", function(data){
	console.log(data)
});