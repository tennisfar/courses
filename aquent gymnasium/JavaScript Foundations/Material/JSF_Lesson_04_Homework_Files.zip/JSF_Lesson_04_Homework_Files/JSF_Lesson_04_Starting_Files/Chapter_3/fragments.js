var standings = [
	{
		name: "New England Patriots",
		wins: 12,
		losses: 4,
		ties: 0
	},
	{
		name: "New York Jets",
		wins: 8,
		losses: 8,
		ties: 0
	},
	{
		name: "Miami Dolphins",
		wins: 8,
		losses: 8,
		ties: 0
	},
	{
		name: "Buffalo Bills",
		wins: 6,
		losses: 10,
		ties: 0
	}
];