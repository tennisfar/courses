document.addEventListener("DOMContentLoaded", function(){
	console.log("window: " + window);
	console.log("document: " + document);
	console.log("document.head: " + document.head);
	console.log("document.title: " + document.title);
	console.log("document.body: " + document.body);
});