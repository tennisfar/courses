document.addEventListener("DOMContentLoaded", function(){
	var elems = document.querySelectorAll("p span.exciting");
	
	elems[0].style.backgroundColor = "red";
});