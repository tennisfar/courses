	var message = "Welcome to my site!";
	
	window.addEventListener("load", function() {
    var header = document.getElementById("header");
    header.textContent = message;
});