
(function() {
	var message = "Welcome to my site!";
    var header = document.getElementById("header");
    header.textContent = message;
})();